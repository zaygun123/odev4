watch1= {
    marka:'Michael Kors',
    type: 'women',
    feature: {
        ürün: 'çelik',
        çap: '39mm',
        şekil:'yuvarlak',
        sugeçirmezlik:'5atm',
        renk:'bronz'
    
        
    },
    gender:"KADIN"
    
}
watch2 = {
    marka:'Michael Kors',
    type: 'gwomen',
    feature: {
        ürün: 'çelik',
        çap: '39mm',
        şekil:'yuvarlak',
        sugeçirmezlik:'5atm',
        renk:'altın'
    },
    
     gender:"KADIN"
    
}
watch3= {
    marka:'Michael Kors',
    type: 'women',
    feature: {
        ürün: 'çelik',
        çap: '36mm',
        şekil:'yuvarlak',
        sugeçirmezlik:'3atm',
        renk:'gümüş'
    },
    gender:"KADIN"
    
    
}
watch4= {
    marka:'Welder Moody Watch',
    type: 'man',
    feature: {
        ürün: 'çelik',
        çap: '45mm',
        şekil:'yuvarlak',
        sugeçirmezlik:'5atm',
        renk:'siyah'
    },
    gender:"ERKEK"
    
    
}
watch5= {
    marka:'Diesel',
    type: 'man',
    feature: {
        ürün: 'silikon',
        çap: '44mm',
        şekil:'yuvarlak',
        sugeçirmezlik:'10atm',
        renk:'siyah'
    },
    gender5:"ERKEK"
    
}
watch6= {
    marka:'Diesel',
    type: 'man',
    feature: {
        ürün: 'çelik',
        çap: '52mm',
        şekil:'yuvarlak',
        sugeçirmezlik:'10atm',
        renk:'siyah'
    },
    gender:"ERKEK"
    
    
}
watch7= {
    marka:'Xiaomi',
    type: 'unisex',
    feature: {
        ürün: 'silikon',
        sugeçirmezlik:'5atm',
        renk:'siyah'
    },
    gender:"AKILLI"
    
    
}
watch8= {
    marka:'Apple',
    type: 'unisex',
    feature: {
        ürün: 'silikon',
        çap: '38mm',
        sugeçirmezlik:'5atm',
        renk:'beyaz'
    },
    gender:"AKILLI"
    
}
watch9= {
    marka:'Smartberry',
    type: 'kids',
    feature: {
        ürün: 'silikon',
        çap: '48mm',
        sugeçirmezlik:'5atm',
        renk:'mavi'
    },
    gender:"ÇOCUK"
    
    
}


function showUser(value) {
     
   var btn=document.createElement("button");
   btn.setAttribute("id","btn1");
   btn.setAttribute("name","btn1");

    document.querySelector('.marka').innerHTML +=`
    marka: ${watch1.marka}
    `

    document.querySelector('.type').innerHTML += `
        type: ${watch1.type}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>ürün: ${watch1.feature.ürün}</span>
    <span>çap: ${watch1.feature.çap}</span>
    <span>şekil: ${watch1.feature.şekil}</span>
    <span>sugeçirmezlik: ${watch1.feature.sugeçirmezlik}</span>
    <span>renk: ${watch1.feature.renk}</span>

`

    document.querySelector('.gender').innerHTML += `
     gender: ${watch1.gender}

`
     document.getElementById("btn").disabled = true;
}
function showUser1(value) {
    
    var btn2=document.createElement("button2");
   btn2.setAttribute("id","btn2");
   btn2.setAttribute("name","btn2");

    document.querySelector('.marka').innerHTML +=`
    marka: ${watch2.marka}
    `

    document.querySelector('.type').innerHTML += `
        type: ${watch2.type}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>ürün: ${watch2.feature.ürün}</span>
    <span>çap: ${watch2.feature.çap}</span>
    <span>şekil: ${watch2.feature.şekil}</span>
    <span>sugeçirmezlik: ${watch2.feature.sugeçirmezlik}</span>
    <span>renk: ${watch2.feature.renk}</span>

`

    document.querySelector('.gender').innerHTML += `
     gender: ${watch2.gender}

`
     document.getElementById("btn").disabled = true;
}
function showUser(value) {

    document.querySelector('.marka').innerHTML +=`
    marka: ${watch3.marka}
    `

    document.querySelector('.type').innerHTML += `
        type: ${watch3.type}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>ürün: ${watch3.feature.ürün}</span>
    <span>çap: ${watch3.feature.çap}</span>
    <span>şekil: ${watch3.feature.şekil}</span>
    <span>sugeçirmezlik: ${watch3.feature.sugeçirmezlik}</span>
    <span>renk: ${watch3.feature.renk}</span>

`

    document.querySelector('.gender').innerHTML += `
     gender: ${watch3.gender}

`
     document.getElementById("btn").disabled = true;
}
function showUser(value) {

    document.querySelector('.marka').innerHTML +=`
    marka: ${watch4.marka}
    `

    document.querySelector('.type').innerHTML += `
        type: ${watch4.type}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>ürün: ${watch4.feature.ürün}</span>
    <span>çap: ${watch4.feature.çap}</span>
    <span>şekil: ${watch4.feature.şekil}</span>
    <span>sugeçirmezlik: ${watch4.feature.sugeçirmezlik}</span>
    <span>renk: ${watch4.feature.renk}</span>

`

    document.querySelector('.gender').innerHTML += `
     gender: ${watch4.gender}

`
     document.getElementById("btn").disabled = true;
}
function showUser(value) {

    document.querySelector('.marka').innerHTML +=`
    marka: ${watch5.marka}
    `

    document.querySelector('.type').innerHTML += `
        type: ${watch5.type}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>ürün: ${watch5.feature.ürün}</span>
    <span>çap: ${watch5.feature.çap}</span>
    <span>şekil: ${watch5.feature.şekil}</span>
    <span>sugeçirmezlik: ${watch5.feature.sugeçirmezlik}</span>
    <span>renk: ${watch5.feature.renk}</span>

`

    document.querySelector('.gender').innerHTML += `
     gender: ${watch5.gender}

`
     document.getElementById("btn").disabled = true;
}
function showUser(value) {

    document.querySelector('.marka').innerHTML +=`
    marka: ${watch6.marka}
    `

    document.querySelector('.type').innerHTML += `
        type: ${watch6.type}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>ürün: ${watch6.feature.ürün}</span>
    <span>çap: ${watch6.feature.çap}</span>
    <span>şekil: ${watch6.feature.şekil}</span>
    <span>sugeçirmezlik: ${watch6.feature.sugeçirmezlik}</span>
    <span>renk: ${watch6.feature.renk}</span>

`

    document.querySelector('.gender').innerHTML += `
     gender: ${watch6.gender}

`
     document.getElementById("btn").disabled = true;
}
function showUser(value) {

    document.querySelector('.marka').innerHTML +=`
    marka: ${watch7.marka}
    `

    document.querySelector('.type').innerHTML += `
        type: ${watch7.type}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>ürün: ${watch7.feature.ürün}</span>
    <span>çap: ${watch7.feature.çap}</span>
    <span>şekil: ${watch7.feature.şekil}</span>
    <span>sugeçirmezlik: ${watch7.feature.sugeçirmezlik}</span>
    <span>renk: ${watch7.feature.renk}</span>

`

    document.querySelector('.gender').innerHTML += `
     gender: ${watch7.gender}

`
     document.getElementById("btn").disabled = true;
}
function showUser(value) {

    document.querySelector('.marka').innerHTML +=`
    marka: ${watch8.marka}
    `

    document.querySelector('.type').innerHTML += `
        type: ${watch8.type}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>ürün: ${watch8.feature.ürün}</span>
    <span>çap: ${watch8.feature.çap}</span>
    <span>şekil: ${watch8.feature.şekil}</span>
    <span>sugeçirmezlik: ${watch8.feature.sugeçirmezlik}</span>
    <span>renk: ${watch8feature.renk}</span>

`

    document.querySelector('.gender').innerHTML += `
     gender: ${watch8.gender}

`
     document.getElementById("btn").disabled = true;
}
function showUser(value) {

    document.querySelector('.marka').innerHTML +=`
    marka: ${watch9.marka}
    `

    document.querySelector('.type').innerHTML += `
        type: ${watch9.type}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>ürün: ${watch9.feature.ürün}</span>
    <span>çap: ${watch9.feature.çap}</span>
    <span>şekil: ${watch9.feature.şekil}</span>
    <span>sugeçirmezlik: ${watch9.feature.sugeçirmezlik}</span>
    <span>renk: ${watch9.feature.renk}</span>

`

    document.querySelector('.gender').innerHTML += `
     gender: ${watch9.gender}

`
     document.getElementById("btn").disabled = true;
}

